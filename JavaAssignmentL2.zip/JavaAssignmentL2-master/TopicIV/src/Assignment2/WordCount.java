package Assignment2;

public interface WordCount {
	
	int count(String str);

}

