package assignment1;

public interface CharacterOccurence {
	
	int findOccurence(String str, char c);

}
