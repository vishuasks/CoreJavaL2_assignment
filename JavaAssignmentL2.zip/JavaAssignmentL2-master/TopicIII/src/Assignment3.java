import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Assignment3 {
	
		public static void main(String[] args) throws IOException {
		        FileReader fr = new FileReader("input.txt"); 
		        BufferedReader br = new BufferedReader(fr); 
		        FileWriter fw = new FileWriter("outfile.txt"); 
		        String line;

		        int lineNum = 0;
		        while((line = br.readLine()) != null)
		        { 
		            if (lineNum > 1) {
		                //make sure we ignore any empty lines
		                if (line.trim().length() > 0) {
		                    //add a space to the end of each line to make 
		                    //padding before we append the next line.
		                    line=line.trim().replaceAll("\\s+", " ") + " ";
		                }
		            } else {
		                //remove all whitespace.
		                line = line.trim().replaceAll("\\s", "");
		                line = line + "\n";
		            }
		            fw.write(line);
		            lineNum++;
		        }
		        fr.close();
		        fw.close();
		}

	    
}

