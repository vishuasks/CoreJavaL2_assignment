import java.util.*;
public class assignment1 {
	
	 static int count=0;
	    assignment1()       //u
	    {
	        count++;
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		assignment1 obj1 = new assignment1();
		assignment1 obj2 = new assignment1();
		assignment1 obj3 = new assignment1();
		assignment1 obj4 = new assignment1();
		assignment1 obj5 = new assignment1();
		assignment1 obj6 = new assignment1();
		System.out.println("number of objects created at a instances is :: "+count);

	}

}
